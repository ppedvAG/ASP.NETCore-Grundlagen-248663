﻿namespace MovieStore.Models
{
    public enum MovieGenre
    {
        Action,
        Adventure,
        Animation,
        Classic,
        Comedy,
        Crime,
        Drama,
        Horror,
        Mystery,
        SciFi,
        Thriller
    }
}
